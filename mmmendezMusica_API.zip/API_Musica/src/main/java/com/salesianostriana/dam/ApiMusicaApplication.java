package com.salesianostriana.dam;

import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.core.annotation.Order;

import com.salesianostriana.dam.model.Album;
import com.salesianostriana.dam.model.Cancion;
import com.salesianostriana.dam.repository.AlbumRepository;
import com.salesianostriana.dam.repository.CancionRepository;

@SpringBootApplication
public class ApiMusicaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiMusicaApplication.class, args);
	}


	

	
	@Bean
	public CommandLineRunner Album(AlbumRepository repo, CancionRepository canRep){
		return (args) -> {
			Date cal1 = Date.valueOf("2015-02-06");
			Date cal2 = Date.valueOf("2008-04-19");
			List<Cancion> ahfod = new ArrayList<Cancion>();
			List<Cancion> vlv = new ArrayList<Cancion>();
			
	
			
			Album alb1 = repo.save(new Album((long) 1,"A Head Full Of Dream","Coldplay",cal1, ahfod));
			Album alb2 = repo.save(new Album((long) 2,"Viva La Vida","Coldplay",cal2, vlv ));	
			
	
			canRep.save(new Cancion((long) 1,"A Head Full Of Dream",(float) 3.33,(long)1000,alb1)); 
			canRep.save(new Cancion((long) 2,"Birds",(float) 2.33,1000, alb1)); 
			canRep.save(new Cancion((long) 3,"Hymn For The Weekend",(float) 3.00,(long)1000,alb1)); 
			canRep.save(new Cancion((long) 4,"Everglow",(float) 2.33,(long)1000,alb1)); 
			canRep.save(new Cancion((long) 5,"Adventure Of Lifetime",(float) 2.00,(long)1000,alb1)); 
			
			
			canRep.save(new Cancion((long) 6,"Life in Tenchnicolor",(float) 3.33,(long)1000,alb2));
			canRep.save(new Cancion((long) 7,"Cementeries Of London",(float) 3.33,(long)1000,alb2));
			canRep.save(new Cancion((long) 8,"Lost!",(float) 3.33,(long)1000,alb2));
			canRep.save(new Cancion((long) 9,"Viva La Vida",(float) 3.33,(long)1000,alb2));
			canRep.save(new Cancion((long) 10,"42",(float) 3.33,(long)1000,alb2));
			
			
			};
		}
	
//	@Bean
//	public CommandLineRunner  Cancion(CancionRepository repo) {
//		return (args) -> {
//			
//			repo.save(new Cancion((long) 1,"A Head Full Of Dream",(float) 3.33,1000 ));
//			repo.save(new Cancion((long) 2,"Birds",(float) 2.33,1000));
//			repo.save(new Cancion((long) 3,"Hymn For The Weekend",(float) 3.00,1000 ));
//			repo.save( new Cancion((long) 4,"Everglow",(float) 2.33,1000));
//			repo.save( new Cancion((long) 5,"Adventure Of Lifetime",(float) 2.00,1000));
//			
//			repo.save( new Cancion((long) 6,"Life in Tenchnicolor",(float) 3.33,1000));
//			repo.save(new Cancion((long) 7,"Cementeries Of London",(float) 3.33,1000));
//			repo.save(new Cancion((long) 8,"Lost!",(float) 3.33,1000));
//			repo.save(new Cancion((long) 9,"Viva La Vida",(float) 3.33,1000));
//			repo.save(new Cancion((long) 10,"42",(float) 3.33,1000));
//			
//			
//			};
//		}
}

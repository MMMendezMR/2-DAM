package com.salesianostriana.dam.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;
import org.springframework.stereotype.Repository;

import com.salesianostriana.dam.model.Cancion;

@RepositoryRestResource(collectionResourceRel = "cancion", path = "canciones")
public interface CancionRepository extends JpaRepository<Cancion, Long>{
	
	List<Cancion> findAll();
	
	List<Cancion> findByTituloContainingIgnoreCase(String tit);
}
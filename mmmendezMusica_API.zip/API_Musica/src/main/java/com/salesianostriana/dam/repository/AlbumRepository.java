package com.salesianostriana.dam.repository;

import java.sql.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import com.salesianostriana.dam.model.Album;




@RepositoryRestResource(collectionResourceRel = "album", path = "albunes")
public interface AlbumRepository extends JpaRepository<Album, Long>{
	
	List<Album> findByAutorContainingIgnoreCase(String autor);
	
	List<Album> findByAnyoLanzamiento(Date anyo);

	
}

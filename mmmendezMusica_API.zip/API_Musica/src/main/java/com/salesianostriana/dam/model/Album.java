package com.salesianostriana.dam.model;


import java.sql.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Album {
	@Id
	private Long id;
	private String titulo;
	private String autor;
	private Date anyoLanzamiento;
	@OneToMany(mappedBy="album", cascade=CascadeType.ALL)
	private List<Cancion> listCanciones;
	//
	
	
	public Album() { }
	
	//constructor para añadir datos manualmente
	public Album(Long id, String titulo, String autor, Date anyoLanzamiento, List<Cancion> listCanciones) {
		this.titulo = titulo;
		this.autor = autor;
		this.anyoLanzamiento = anyoLanzamiento;
		this.listCanciones = listCanciones;
		this.id = id;
	}
	
	public Album(String titulo, String autor, Date anyoLanzamiento, List<Cancion> listCanciones) {
		this.titulo = titulo;
		this.autor = autor;
		this.anyoLanzamiento = anyoLanzamiento;
		this.listCanciones = listCanciones;
	}
	
	
	
	public String getTitulo() {
		return titulo;
	}
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
	public String getAutor() {
		return autor;
	}
	public void setAutor(String autor) {
		this.autor = autor;
	}
	public Date getAnyoLanzamiento() {
		return anyoLanzamiento;
	}
	public void setAnyoLanzamiento(Date anyoLanzamiento) {
		this.anyoLanzamiento = anyoLanzamiento;
	}
	public List<Cancion> getListCanciones() {
		return listCanciones;
	}
	public void setListCanciones(List<Cancion> listCanciones) {
		this.listCanciones = listCanciones;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}

	
	
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((anyoLanzamiento == null) ? 0 : anyoLanzamiento.hashCode());
		result = prime * result + ((autor == null) ? 0 : autor.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((listCanciones == null) ? 0 : listCanciones.hashCode());
		result = prime * result + ((titulo == null) ? 0 : titulo.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Album other = (Album) obj;
		if (anyoLanzamiento == null) {
			if (other.anyoLanzamiento != null)
				return false;
		} else if (!anyoLanzamiento.equals(other.anyoLanzamiento))
			return false;
		if (autor == null) {
			if (other.autor != null)
				return false;
		} else if (!autor.equals(other.autor))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (listCanciones == null) {
			if (other.listCanciones != null)
				return false;
		} else if (!listCanciones.equals(other.listCanciones))
			return false;
		if (titulo == null) {
			if (other.titulo != null)
				return false;
		} else if (!titulo.equals(other.titulo))
			return false;
		return true;
	}

	
	
	
	@Override
	public String toString() {
		return "Album [id=" + id + ", titulo=" + titulo + ", autor=" + autor + ", anyoLanzamiento=" + anyoLanzamiento
				+ ", listCanciones=" + listCanciones + "]";
	}
}

package com.salesianostriana.dam.modelo;

import javax.persistence.Embeddable;

@Embeddable
public class Direccion {

	private String calleynumero;
	private String cp;
	private String poblacion;
	private String provincia;
	
	
	
	
	public Direccion() { }
	
	public Direccion(String calleynumero, String cp, String poblacion, String provincia) {
		this.calleynumero = calleynumero;
		this.cp = cp;
		this.poblacion = poblacion;
		this.provincia = provincia;
	}
	
	
	
	
	
	public String getCalleynumero() {
		return calleynumero;
	}
	public void setCalleynumero(String calleynumero) {
		this.calleynumero = calleynumero;
	}
	public String getCp() {
		return cp;
	}
	public void setCp(String cp) {
		this.cp = cp;
	}
	public String getPoblacion() {
		return poblacion;
	}
	public void setPoblacion(String poblacion) {
		this.poblacion = poblacion;
	}
	public String getProvincia() {
		return provincia;
	}
	public void setProvincia(String provincia) {
		this.provincia = provincia;
	}
	
	
	
	
	
	
	@Override
	public String toString() {
		return "Dirección [calleynumero=" + calleynumero + ", cp=" + cp + ", poblacion=" + poblacion + ", provincia="
				+ provincia + "]";
	}
	
}

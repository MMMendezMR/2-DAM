package com.salesianostriana.dam;


import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.salesianostriana.dam.Repositorio.PersonaRepository;
import com.salesianostriana.dam.modelo.Direccion;
import com.salesianostriana.dam.modelo.Persona;

@SpringBootApplication
public class MyRestDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyRestDemoApplication.class, args);
	}
	
	@Bean
	public CommandLineRunner demo(PersonaRepository repository) {
		return (args) -> {
			//Varias personas de prueva
			repository.save(new Persona("Marta Mª","Méndez Martínez", 
					new Direccion("Fco Collantes de terán", "41010", "Sevilla", "Sevilla")));
			repository.save(new Persona("Marta","Méndez",
					new Direccion("Fco Collantes de terán", "41010", "Sevilla", "Sevilla")));
			repository.save(new Persona("Mª","Martínez",
					new Direccion("Fco Collantes de terán", "41010", "Sevilla", "Sevilla")));
			repository.save(new Persona("Javi","Hefoo",
					new Direccion("Fco Collantes de terán", "41010", "Sevilla", "Sevilla")));
			};
		}
}

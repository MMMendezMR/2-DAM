package com.salesianostriana.dam.controladores;

import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;

import com.salesianostriana.dam.Error;
import com.salesianostriana.dam.Errores.PersonaSinDatosException;
import com.salesianostriana.dam.modelo.Persona;
import com.salesianostriana.dam.servicios.PersonaService;

@Controller
@ResponseBody
public class WelcomeController {
	
	@Autowired
	PersonaService perser;

	@GetMapping("/personas")
	public List<Persona> Welcome() {
		return perser.findAll();
	}
	
	@GetMapping("/persona/{id}")
	public Persona obtenerUnaPersona(@PathVariable("id") Long id) {
		return perser.findOne(id);
	}
	
	
//____Opciones de devolución de errores_________________________________________________________
	
/**	//1
	@PostMapping("/persona")
	public Persona crearUnaPersona(@RequestBody Persona pers, HttpServletResponse response) {
		
		if (pers.getNombre() != null && pers.getApellidos() != null) {
			response.setStatus(201);
			return perser.guardar(pers);
		}
		else {
			response.setStatus(404);
			return null;
		}
	}
 **/
	
	
/**	//2
	@PostMapping("/persona")
	public ResponseEntity<?> crearUnaPersona(@RequestBody Persona pers, HttpServletResponse response) {
		
		if (pers.getNombre() != null && pers.getApellidos() != null) {
			Persona p = perser.guardar(pers);
			return new ResponseEntity<Persona>(p, HttpStatus.CREATED);
		}
		else {
			return new ResponseEntity<Error>(
					new Error(400,"Falta el nombre y/o los apellidos del usuario"),
					HttpStatus.BAD_REQUEST);
		}
	}
**/
	
	//3
	@PostMapping("/persona")
	public ResponseEntity<?> crearUnaPersona(@RequestBody Persona pers, HttpServletResponse response) {
		
		if (pers.getNombre() != null && pers.getApellidos() != null) {
			Persona p = perser.guardar(pers);
			return new ResponseEntity<Persona>(p, HttpStatus.CREATED);
		}
		else {
			return null; //throw new PersonaSinDatosException();
		}
	}
	
	
	
//______________________________________________________________________________________________	

	
	//1er ejemplo guay de editar 
	@PutMapping
	public Persona editarUnaPersona(@RequestBody Persona pers) {
		if(perser.findOne(pers.getId()) != null) {
			return perser.editar(pers);
		}
		return null;
	}
	
	//2º ejemplo no tan guay de editar
/**	@PutMapping
	public Persona editarUnaPersonaConId(@PathVariable("id") Long id,
			@RequestBody Persona pers) {
		if(perser.findOne(id) != null) {
			return perser.editar(pers);
		}
		return null;
	}
**/	
	
	@DeleteMapping("/persona")
	public Persona eliminarUnaPersona(@RequestBody Persona pers) {
		perser.borrar(pers.getId());
		return null;
	}
}

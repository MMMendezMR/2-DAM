package com.salesianostriana.dam.servicios;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.salesianostriana.dam.modelo.Persona;
import com.salesianostriana.dam.Repositorio.PersonaRepository;

@Service
public class PersonaService {
	
	@Autowired
	PersonaRepository repo;
	
	public List<Persona> findAll(){
		return repo.findAll();
	}
	
	public Persona findOne(Long id) {
		return repo.findOne(id);
	}
	
	public Persona guardar(Persona persona) {
		return repo.save(persona);
	}
	
	public void borrar(Long id) {
		repo.delete(repo.findOne(id));
	}
	
	public Persona editar(Persona persona) {
		return repo.save(persona);
	}
}


package com.salesianostriana.dam.Repositorio;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.salesianostriana.dam.modelo.Persona;

@Repository
public interface PersonaRepository extends JpaRepository<Persona, Long>{

	List<Persona> findByNombreContainingIgnoreCase(String nombre);

	List<Persona> findByApellidosContainingIgnoreCase(String apellido);

	List<Persona> findByNombreAndApellidosContainingIgnoreCase(String nombre, String apellido);

}

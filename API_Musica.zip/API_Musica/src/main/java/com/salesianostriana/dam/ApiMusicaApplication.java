package com.salesianostriana.dam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiMusicaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiMusicaApplication.class, args);
	}
}

package com.salesianostriana.dam.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Cancion {
	@Id
	private Long id;
	private String titulo;
	private float duracion;
	private long nLikes;
	private Album album;
	
	
	
	public Cancion() { }
	
	public Cancion(String titulo, float duracion, long nLikes, Album album, Long id) {
		this.titulo = titulo;
		this.duracion = duracion;
		this.nLikes = nLikes;
		this.album = album;
		this.id = id;
	}
	
	
	
	public String getTitulo() {
		return titulo;
	}
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
	public float getDuracion() {
		return duracion;
	}
	public void setDuracion(float duracion) {
		this.duracion = duracion;
	}
	public long getnLikes() {
		return nLikes;
	}
	public void setnLikes(long nLikes) {
		this.nLikes = nLikes;
	}
	public Album getAlbum() {
		return album;
	}
	public void setAlbum(Album album) {
		this.album = album;
	}
	public Long getId() {
		return id;
	}
	
	
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((album == null) ? 0 : album.hashCode());
		result = prime * result + Float.floatToIntBits(duracion);
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + (int) (nLikes ^ (nLikes >>> 32));
		result = prime * result + ((titulo == null) ? 0 : titulo.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Cancion other = (Cancion) obj;
		if (album == null) {
			if (other.album != null)
				return false;
		} else if (!album.equals(other.album))
			return false;
		if (Float.floatToIntBits(duracion) != Float.floatToIntBits(other.duracion))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (nLikes != other.nLikes)
			return false;
		if (titulo == null) {
			if (other.titulo != null)
				return false;
		} else if (!titulo.equals(other.titulo))
			return false;
		return true;
	}

	public void setId(Long id) {
		this.id = id;
	}
	
	
	

	@Override
	public String toString() {
		return "Cancion [id=" + id + ", titulo=" + titulo + ", duracion=" + duracion + ", nLikes=" + nLikes + ", album="
				+ album + "]";
	}
}

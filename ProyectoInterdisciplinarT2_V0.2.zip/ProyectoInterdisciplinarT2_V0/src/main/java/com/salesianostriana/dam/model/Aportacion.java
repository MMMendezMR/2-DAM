package com.salesianostriana.dam.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class Aportacion {
	@Id
	@GeneratedValue(strategy =GenerationType.AUTO )
	private Long id;
	@ManyToOne
	private Campanya estaCampanya;
	@ManyToOne
	private DatosMaestros idTipoDatos;
	private Long cantidad;
	@ManyToOne
	private Usuario key;
	
	
	
	public Aportacion() {
	}
	
	public Aportacion(Campanya idCampanya, DatosMaestros idTipoDatos, Long cantidad, Usuario key) {
		this.estaCampanya = idCampanya;
		this.idTipoDatos = idTipoDatos;
		this.cantidad = cantidad;
		this.key = key;
	}
	
//	public Aportacion(Long id, Campanya idCampanya, DatosMaestros idTipoDatos, Long cantidad, Usuario nombre) {
//		this.id = id;
//		this.idCampanya = idCampanya;
//		this.idTipoDatos = idTipoDatos;
//		this.cantidad = cantidad;
//		this.nombre = nombre;
//	}
	
	
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Campanya getIdCampanya() {
		return estaCampanya;
	}
	public void setIdCampanya(Campanya idCampanya) {
		this.estaCampanya = idCampanya;
	}
	public DatosMaestros getIdTipoDatos() {
		return idTipoDatos;
	}
	public void setIdTipoDatos(DatosMaestros idTipoDatos) {
		this.idTipoDatos = idTipoDatos;
	}
	public Long getCantidad() {
		return cantidad;
	}
	public void setCantidad(Long cantidad) {
		this.cantidad = cantidad;
	}
	public Usuario getNombre() {
		return key;
	}
	public void setNombre(Usuario key) {
		this.key = key;
	}
	
	
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((cantidad == null) ? 0 : cantidad.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((estaCampanya == null) ? 0 : estaCampanya.hashCode());
		result = prime * result + ((idTipoDatos == null) ? 0 : idTipoDatos.hashCode());
		result = prime * result + ((key == null) ? 0 : key.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Aportacion other = (Aportacion) obj;
		if (cantidad == null) {
			if (other.cantidad != null)
				return false;
		} else if (!cantidad.equals(other.cantidad))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (estaCampanya == null) {
			if (other.estaCampanya != null)
				return false;
		} else if (!estaCampanya.equals(other.estaCampanya))
			return false;
		if (idTipoDatos == null) {
			if (other.idTipoDatos != null)
				return false;
		} else if (!idTipoDatos.equals(other.idTipoDatos))
			return false;
		if (key == null) {
			if (other.key != null)
				return false;
		} else if (!key.equals(other.key))
			return false;
		return true;
	}
	
	
	
	@Override
	public String toString() {
		return "Aportacion [id=" + id + ", idCampanya=" + estaCampanya + ", idTipoDatos=" + idTipoDatos + ", cantidad="
				+ cantidad + ", key=" + key + "]";
	}
	
}

package com.salesianostriana.dam.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class Aportacion {
	@Id
	@GeneratedValue(strategy =GenerationType.AUTO )
	private Long id;
	@ManyToOne
	private Campanya idCampanya;
	@ManyToOne
	private DatosMaestros idTipoDatos;
	private Long cantidad;
	@ManyToOne
	private Usuario nombre;
	
	
	
	public Aportacion() {
	}
	
	public Aportacion(Long id, Campanya idCampanya, DatosMaestros idTipoDatos, Long cantidad, Usuario nombre) {
		this.id = id;
		this.idCampanya = idCampanya;
		this.idTipoDatos = idTipoDatos;
		this.cantidad = cantidad;
		this.nombre = nombre;
	}
	
	
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Campanya getIdCampanya() {
		return idCampanya;
	}
	public void setIdCampanya(Campanya idCampanya) {
		this.idCampanya = idCampanya;
	}
	public DatosMaestros getIdTipoDatos() {
		return idTipoDatos;
	}
	public void setIdTipoDatos(DatosMaestros idTipoDatos) {
		this.idTipoDatos = idTipoDatos;
	}
	public Long getCantidad() {
		return cantidad;
	}
	public void setCantidad(Long cantidad) {
		this.cantidad = cantidad;
	}
	public Usuario getNombre() {
		return nombre;
	}
	public void setNombre(Usuario nombre) {
		this.nombre = nombre;
	}
	
	
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((cantidad == null) ? 0 : cantidad.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((idCampanya == null) ? 0 : idCampanya.hashCode());
		result = prime * result + ((idTipoDatos == null) ? 0 : idTipoDatos.hashCode());
		result = prime * result + ((nombre == null) ? 0 : nombre.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Aportacion other = (Aportacion) obj;
		if (cantidad == null) {
			if (other.cantidad != null)
				return false;
		} else if (!cantidad.equals(other.cantidad))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (idCampanya == null) {
			if (other.idCampanya != null)
				return false;
		} else if (!idCampanya.equals(other.idCampanya))
			return false;
		if (idTipoDatos == null) {
			if (other.idTipoDatos != null)
				return false;
		} else if (!idTipoDatos.equals(other.idTipoDatos))
			return false;
		if (nombre == null) {
			if (other.nombre != null)
				return false;
		} else if (!nombre.equals(other.nombre))
			return false;
		return true;
	}
	
	
	
	@Override
	public String toString() {
		return "Aportacion [id=" + id + ", idCampanya=" + idCampanya + ", idTipoDatos=" + idTipoDatos + ", cantidad="
				+ cantidad + ", nombre=" + nombre + "]";
	}
	
}

package com.salesianostriana.dam.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class Campanya {
	@Id
	@GeneratedValue(strategy =GenerationType.AUTO )
	private Long id;
	private String codigo;
	@ManyToMany
	private List<Usuario> usuariosApuntados;
	@OneToMany(mappedBy="campanya", cascade=CascadeType.ALL)
	private List<DatosMaestros> categorias;
	@OneToMany(mappedBy="estaCampanya", cascade=CascadeType.ALL)
	private List<Aportacion> aportaciones;
	
	
	public Campanya() {

	}
	public Campanya(String codigo, List<DatosMaestros> categorias) {
		this.codigo = codigo;
		this.categorias = categorias;
	}
	
	public Campanya(Long id, String codigo, List<Usuario> usuariosApuntados, List<DatosMaestros> categorias,
			List<Aportacion> aportaciones) {
		this.id = id;
		this.codigo = codigo;
		this.usuariosApuntados = usuariosApuntados;
		this.categorias = categorias;
		this.aportaciones = aportaciones;
	}
	
	
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getCodigo() {
		return codigo;
	}
	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}
	public List<Usuario> getUsuariosApuntados() {
		return usuariosApuntados;
	}
	public void setUsuariosApuntados(List<Usuario> usuariosApuntados) {
		this.usuariosApuntados = usuariosApuntados;
	}
	public List<DatosMaestros> getCategorias() {
		return categorias;
	}
	@JsonIgnore
	public void setCategorias(List<DatosMaestros> categorias) {
		this.categorias = categorias;
	}
	public List<Aportacion> getAportaciones() {
		return aportaciones;
	}
	public void setAportaciones(List<Aportacion> aportaciones) {
		this.aportaciones = aportaciones;
	}
	
	
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((aportaciones == null) ? 0 : aportaciones.hashCode());
		result = prime * result + ((codigo == null) ? 0 : codigo.hashCode());
		result = prime * result + ((categorias == null) ? 0 : categorias.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((usuariosApuntados == null) ? 0 : usuariosApuntados.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Campanya other = (Campanya) obj;
		if (aportaciones == null) {
			if (other.aportaciones != null)
				return false;
		} else if (!aportaciones.equals(other.aportaciones))
			return false;
		if (codigo == null) {
			if (other.codigo != null)
				return false;
		} else if (!codigo.equals(other.codigo))
			return false;
		if (categorias == null) {
			if (other.categorias != null)
				return false;
		} else if (!categorias.equals(other.categorias))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (usuariosApuntados == null) {
			if (other.usuariosApuntados != null)
				return false;
		} else if (!usuariosApuntados.equals(other.usuariosApuntados))
			return false;
		return true;
	}
	
	
	
	@Override
	public String toString() {
		return "Campanya [id=" + id + ", codigo=" + codigo + ", usuariosApuntados=" + usuariosApuntados
				+ ", categorias=" + categorias + ", aportaciones=" + aportaciones + "]";
	}
	
}

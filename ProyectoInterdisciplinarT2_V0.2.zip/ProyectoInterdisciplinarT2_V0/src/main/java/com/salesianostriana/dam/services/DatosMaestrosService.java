package com.salesianostriana.dam.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.salesianostriana.dam.model.DatosMaestros;
import com.salesianostriana.dam.repository.DatosMaestrosRepository;


@Service
public class DatosMaestrosService {
	
	@Autowired
	DatosMaestrosRepository repo;
	
	public List<DatosMaestros> findAll(){
		return repo.findAll();
	}
	
	public DatosMaestros findById(Long id) {
		return repo.findOne(id);
	}
	
	public DatosMaestros guardar (DatosMaestros datosM){
		return repo.save(datosM);
	}

	public void borrar(Long id) {
		repo.delete(id);
	}

	public List<DatosMaestros> findByNombre(String nombre){
		return repo.findByNombreContainingIgnoreCase(nombre);
	}

	public DatosMaestros finById(Long id) {
		return repo.findOne(id);
	}

}

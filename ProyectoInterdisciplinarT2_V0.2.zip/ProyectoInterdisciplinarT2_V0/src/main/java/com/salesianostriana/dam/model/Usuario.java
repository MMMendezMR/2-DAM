package com.salesianostriana.dam.model;

import java.security.NoSuchAlgorithmException;
import java.util.List;

import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.xml.bind.DatatypeConverter;

@Entity
public class Usuario {
	@Id
	@GeneratedValue(strategy =GenerationType.AUTO )
	private Long id;
	private String nombre;
	private String correo;
	private String contrasenya;
	private String curso;
	private String key;
	
	@ManyToMany
	private List<Campanya> campanyaApuntado;
	@OneToMany(mappedBy="key", cascade=CascadeType.ALL)
	private List<Aportacion> aportaciones;
	
	
	
	public Usuario() {
	}
	
	public Usuario(String nombre, String correo, String contrasenya) {
		this.nombre = nombre;
		this.correo = correo;
		this.contrasenya = contrasenya;
	}

	public Usuario(String nombre, String correo, String contrasenya, String curso, String key,
			List<Campanya> campanyaApuntado, List<Aportacion> aportaciones) {
		this.nombre = nombre;
		this.correo = correo;
		this.contrasenya = contrasenya;
		this.curso = curso;
		this.key = key;
		this.campanyaApuntado = campanyaApuntado;
		this.aportaciones = aportaciones;
	}
	
	

	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getCorreo() {
		return correo;
	}
	public void setCorreo(String correo) {
		this.correo = correo;
	}
	public String getContrasenya() {
		return contrasenya;
	}
	public void setContrasenya(String contrasenya) {
		this.contrasenya = contrasenya;
	}
	public String getCurso() {
		return curso;
	}
	public void setCurso(String curso) {
		this.curso = curso;
	}
	public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}
	public List<Campanya> getCampanyaApuntado() {
		return campanyaApuntado;
	}
	public void setCampanyaApuntado(List<Campanya> campanyaApuntado) {
		this.campanyaApuntado = campanyaApuntado;
	}
	public List<Aportacion> getAportaciones() {
		return aportaciones;
	}
	public void setAportaciones(List<Aportacion> aportaciones) {
		this.aportaciones = aportaciones;
	}

	
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((aportaciones == null) ? 0 : aportaciones.hashCode());
		result = prime * result + ((campanyaApuntado == null) ? 0 : campanyaApuntado.hashCode());
		result = prime * result + ((contrasenya == null) ? 0 : contrasenya.hashCode());
		result = prime * result + ((correo == null) ? 0 : correo.hashCode());
		result = prime * result + ((curso == null) ? 0 : curso.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((key == null) ? 0 : key.hashCode());
		result = prime * result + ((nombre == null) ? 0 : nombre.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Usuario other = (Usuario) obj;
		if (aportaciones == null) {
			if (other.aportaciones != null)
				return false;
		} else if (!aportaciones.equals(other.aportaciones))
			return false;
		if (campanyaApuntado == null) {
			if (other.campanyaApuntado != null)
				return false;
		} else if (!campanyaApuntado.equals(other.campanyaApuntado))
			return false;
		if (contrasenya == null) {
			if (other.contrasenya != null)
				return false;
		} else if (!contrasenya.equals(other.contrasenya))
			return false;
		if (correo == null) {
			if (other.correo != null)
				return false;
		} else if (!correo.equals(other.correo))
			return false;
		if (curso == null) {
			if (other.curso != null)
				return false;
		} else if (!curso.equals(other.curso))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (key == null) {
			if (other.key != null)
				return false;
		} else if (!key.equals(other.key))
			return false;
		if (nombre == null) {
			if (other.nombre != null)
				return false;
		} else if (!nombre.equals(other.nombre))
			return false;
		return true;
	}
	
	

	@Override
	public String toString() {
		return "Usuario [id=" + id  + ", nombre=" + nombre + ", correo=" + correo
				+ ", contrasenya=" + contrasenya + ", curso=" + curso + ", key=" + key + ", campanyaApuntado="
				+ campanyaApuntado + ", aportaciones=" + aportaciones + "]";
	}
	
	
	
	//Métodos helper
	
	public String generarKey(final int keyLen) throws NoSuchAlgorithmException  {
        KeyGenerator keyGen = KeyGenerator.getInstance("AES");
        keyGen.init(keyLen);
        SecretKey secretKey = keyGen.generateKey();
        byte[] encoded = secretKey.getEncoded();
        return DatatypeConverter.printHexBinary(encoded).toLowerCase();

	}
}

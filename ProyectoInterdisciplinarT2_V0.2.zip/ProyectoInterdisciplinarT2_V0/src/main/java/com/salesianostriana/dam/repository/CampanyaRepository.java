package com.salesianostriana.dam.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import com.salesianostriana.dam.model.Campanya;

@RepositoryRestResource(collectionResourceRel = "Campañas", path = "Campañas")
public interface CampanyaRepository extends JpaRepository<Campanya, Long>{

	List<Campanya> findByCodigoContainingIgnoreCase(String codigo);

}

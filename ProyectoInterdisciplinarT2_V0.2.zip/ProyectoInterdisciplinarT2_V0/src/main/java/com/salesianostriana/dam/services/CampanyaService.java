package com.salesianostriana.dam.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.salesianostriana.dam.model.Campanya;
import com.salesianostriana.dam.repository.CampanyaRepository;

@Service
public class CampanyaService {
 
	@Autowired
	CampanyaRepository repo;
	
	public List<Campanya> findAll(){
		return repo.findAll();
	}
	
	public Campanya findById(Long id) {
		return repo.findOne(id);
	}
	
	public Campanya guardar (Campanya camp){
		return repo.save(camp);
	}

	public void borrar(Long id) {
		repo.delete(id);
	}

	public List<Campanya> findByCodigo(String codigo){
		return repo.findByCodigoContainingIgnoreCase(codigo);
	}

	public Campanya finById(Long id) {
		return repo.findOne(id);
	}
}

package com.salesianostriana.dam.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.salesianostriana.dam.model.Usuario;
import com.salesianostriana.dam.services.LoginService;

@Controller
public class LogInController {
	
	@Autowired
	LoginService service;
	
	@Autowired
	HttpSession session;
	
	@GetMapping("/login")
	public String showLogin(Model model) {
		model.addAttribute("MiUsuario", new Usuario());
		return "login";
				
	}
}

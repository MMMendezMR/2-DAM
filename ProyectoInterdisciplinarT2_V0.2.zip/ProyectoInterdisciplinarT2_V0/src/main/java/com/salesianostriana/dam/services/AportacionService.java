package com.salesianostriana.dam.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.salesianostriana.dam.model.Aportacion;
import com.salesianostriana.dam.repository.AportacionRepository;

@Service
public class AportacionService {

	@Autowired
	AportacionRepository repo;
	
	public List<Aportacion> findAll(){
		return repo.findAll();
	}
	
	public Aportacion findById(Long id) {
		return repo.findOne(id);
	}
	
	public Aportacion guardar (Aportacion aportacion){
		return repo.save(aportacion);
	}

	public void borrar(Long id) {
		repo.delete(id);
	}

	public Aportacion finById(Long id) {
		return repo.findOne(id);
	}
}

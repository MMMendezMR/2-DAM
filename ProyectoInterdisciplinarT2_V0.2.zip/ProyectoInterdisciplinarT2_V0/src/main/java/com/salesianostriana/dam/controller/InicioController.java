package com.salesianostriana.dam.controller;

import java.security.NoSuchAlgorithmException;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.salesianostriana.dam.model.Aportacion;
import com.salesianostriana.dam.model.Campanya;
import com.salesianostriana.dam.model.DatosMaestros;
import com.salesianostriana.dam.model.Usuario;
import com.salesianostriana.dam.repository.AportacionRepository;
import com.salesianostriana.dam.services.CampanyaService;
import com.salesianostriana.dam.services.DatosMaestrosService;
import com.salesianostriana.dam.services.UsuarioService;

@RestController
public class InicioController {

	@Autowired
	UsuarioService usuService;
	
	@Autowired
	CampanyaService campService;
	
	@Autowired
	DatosMaestrosService datService;
	
	@Autowired
	AportacionRepository apService; 
	
/**----------------Métodos de Usuario-----------------*/
	@GetMapping("/listarUsuarios")
	public List<Usuario> listarUsuarios() {
		return usuService.findAll();
	}
	
	//@GetMapping("/findOne") + model para pasarlo a join
	@GetMapping("/findOne/{id}")
	public Usuario encontrarUsuario(@PathVariable("id") Long id){
		return usuService.finById(id);
	}
	
	@CrossOrigin
	@PostMapping("/auth/register")
	public Usuario crearUsuario( Usuario usu, HttpServletResponse response) throws NoSuchAlgorithmException {
		usu.setKey(usu.generarKey(128));
		return usuService.guardar(usu);
	}
	
	@PostMapping("/campaign/join/{codigo}")
	public Usuario joinUsuarioCampania(@PathVariable("codigo") String codigo, @RequestBody Usuario usu,
			HttpServletResponse response ) {
		List<Campanya> estoyUnido= campService.findByCodigo(codigo);
		usu.setCampanyaApuntado(estoyUnido);
		return usu;
		}
	
/**----------------Métodos de Campaña-----------------*/		
	
	@GetMapping("/campaign/list")
	public List<Campanya> listarCampanyas() {
		return campService.findAll();
	}
	
/**----------------Métodos de Aportaciones-----------------*/
	
	@PostMapping("/campaign/add")
	public Aportacion crearAportaciones(@RequestBody Aportacion ap, HttpServletResponse response) {
		return apService.save(ap);
	}

	
/**----------------Métodos de Categorias-----------------*/
	
	@GetMapping("/campaign/datamaster")
	public List<DatosMaestros> listarCategorias() {
		return datService.findAll();
	}
}

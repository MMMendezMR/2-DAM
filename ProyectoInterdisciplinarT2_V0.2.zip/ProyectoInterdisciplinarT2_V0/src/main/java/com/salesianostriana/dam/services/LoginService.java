package com.salesianostriana.dam.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.salesianostriana.dam.model.Usuario;
import com.salesianostriana.dam.repository.UsuarioRepository;

@Service
public class LoginService {

	@Autowired
	UsuarioRepository repo;
	
	public Usuario loginByNombreAndContrasenya(String nombre, String contrasenya) {
		Usuario usuario = repo.findFirstByNombreAndContrasenya(nombre, contrasenya);
		return usuario;
	}
}

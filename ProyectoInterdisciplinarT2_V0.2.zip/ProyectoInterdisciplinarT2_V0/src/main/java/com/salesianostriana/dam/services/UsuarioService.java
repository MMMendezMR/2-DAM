package com.salesianostriana.dam.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.salesianostriana.dam.model.Usuario;
import com.salesianostriana.dam.repository.UsuarioRepository;

@Repository
public class UsuarioService {
	
	@Autowired
	UsuarioRepository repo;
	
	public List<Usuario> findAll(){
		return repo.findAll();
	}
	
	public Usuario findById(Long id) {
		return repo.findOne(id);
	}
	
	public Usuario guardar (Usuario usuario){
		return repo.save(usuario);
	}

	public void borrar(Long id) {
		repo.delete(id);
	}

	public List<Usuario> findByNombre(String nombre){
		return repo.findByNombreContainingIgnoreCase(nombre);
	}

	public Usuario finById(Long id) {
		return repo.findOne(id);
	}
}

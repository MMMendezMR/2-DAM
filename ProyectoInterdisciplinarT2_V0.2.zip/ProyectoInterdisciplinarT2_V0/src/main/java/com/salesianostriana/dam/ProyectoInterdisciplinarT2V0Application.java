package com.salesianostriana.dam;

import java.util.ArrayList;
import java.util.List;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.salesianostriana.dam.model.Usuario;
import com.salesianostriana.dam.model.Campanya;
import com.salesianostriana.dam.model.DatosMaestros;
import com.salesianostriana.dam.repository.CampanyaRepository;
import com.salesianostriana.dam.repository.DatosMaestrosRepository;
import com.salesianostriana.dam.repository.UsuarioRepository;

@SpringBootApplication
public class ProyectoInterdisciplinarT2V0Application {

	
	public static void main(String[] args) {
		SpringApplication.run(ProyectoInterdisciplinarT2V0Application.class, args);
	}
	
	@Bean
	public CommandLineRunner repositorios(UsuarioRepository usuRepo,CampanyaRepository campRepo,DatosMaestrosRepository datRepo) {
		return (args) -> {
			List<DatosMaestros> categorias= new ArrayList<DatosMaestros>();
			usuRepo.save(new Usuario("marta@gmail.com","marta","123456"));
			
			Campanya cKilo = campRepo.save(new Campanya("KILO2017", categorias));
			categorias.add(datRepo.save(new DatosMaestros("Pasta", cKilo)));
			categorias.add(datRepo.save(new DatosMaestros("Arroz", cKilo)));
			categorias.add(datRepo.save(new DatosMaestros("Aceite", cKilo)));
			categorias.add(datRepo.save(new DatosMaestros("Legumbres", cKilo)));
		
		

			cKilo.setCategorias(categorias);		
			};
		}
}

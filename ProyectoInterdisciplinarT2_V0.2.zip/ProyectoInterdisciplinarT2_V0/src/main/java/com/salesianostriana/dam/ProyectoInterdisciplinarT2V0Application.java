package com.salesianostriana.dam;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.salesianostriana.dam.model.Usuario;
import com.salesianostriana.dam.repository.UsuarioRepository;

@SpringBootApplication
public class ProyectoInterdisciplinarT2V0Application {

	public static void main(String[] args) {
		SpringApplication.run(ProyectoInterdisciplinarT2V0Application.class, args);
	}
	
	@Bean
	public CommandLineRunner Usuario(UsuarioRepository repo) {
		return (args) -> {
			repo.save(new Usuario(true,"Marta Méndez", "marta@correo.com","micontraseña123","2DAM","hjaHGjISn674kjiIJijkjkdhu875"));	
			};
		}
}

package com.salesianostriana.dam.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import com.salesianostriana.dam.model.DatosMaestros;

@RepositoryRestResource(collectionResourceRel = "Categorias", path = "Categorias")
public interface DatosMaestrosRepository extends JpaRepository<DatosMaestros, Long>{

	List<DatosMaestros> findByNombreContainingIgnoreCase(String nombre);

}

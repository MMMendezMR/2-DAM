package com.salesianostriana.dam.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import com.salesianostriana.dam.model.Aportacion;

@RepositoryRestResource(collectionResourceRel = "Aportacion", path = "Aportaciones")
public interface AportacionRepository extends JpaRepository<Aportacion, Long>{

}

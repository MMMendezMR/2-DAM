/**
 * 
 */
$(document).on("click","#btnLogin",function(){
  // Obtenemos lo que el usuario ha escrito en los input Email y Password
  // Para obtener el valor que se ha escrito en un input, utilizamos la función .val()
  var e = $("#inputEmail").val();
  var p = $("#inputPassword").val();

  $.ajax({
    method: "POST",
    url: "http://localhost/login",
    data: { email: e, password: p }
  })
  .done(function(Json) {
    // respuesta > es un objeto JSON que recibo del servidor
    let key = Json.key;
    let nombre = Json.nombre;
    let email = Json.email;

    console.log(`${key}, ${nombre}, ${email}`);

    localStorage.setItem("key",key);
    // Redirecciono al usuario a la página de inicio
    window.location.href = "index.html";
  })
  .fail(function(error){
    alert("Login incorrecto");
    console.log(error);
  });

});
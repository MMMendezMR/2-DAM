$(document).ready(function(){
  var baseURL = "http://localhost:8080/";
  var key = localStorage.getItem("key");

  $.ajax({
    method: "GET",
    url: baseURL+"campaign/list",
    data: { "X-API-KEY": key }
  })
  .done(function(Json) {
      console.log(Json);

      var listaCampanyas = Json.campanya;

      listaCampanyas.forEach(function(campanya){
        var htmlCampanya = `
        <tr id="${campanya.id}">
          <td>${campanya.id}</td>
          <td>${campanya.codigo}</td>
          <td>${campanya.usuariosApuntados}</td>
          <td>
              <a href="#" class="btn btn-primary btnEditar">Editar</a>
              <a href="#" class="btn btn-danger btnEliminar">Eliminar</a>
            </td>
          </tr>`;

        $("#listadoCampanyas").append(htmlCampanya);
      });

  })
  .fail(function(error){
    console.log(error);
  });
});
package com.salesianostriana.dam.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;

import com.salesianostriana.dam.model.Campanya;

@Service
public interface CampanyaRepository extends JpaRepository<Campanya, Long>{

}

package com.salesianostriana.dam.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.salesianostriana.dam.repository.UsuarioRepository;

@Repository
public class UsuarioService {
	
	@Autowired
	UsuarioRepository repo;
}
